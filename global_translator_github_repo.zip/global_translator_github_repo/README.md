# 🌐 Global Hybrid Translator (GitHub Auto-Updating PWA / APK)

**Created by W.Vihanga Rasanjana Withanage**

## 1. GitHub එකට දාලා Live කරන විදිහ (Deploy to GitHub Pages)
1. GitHub එකේ අලුත් **Public Repository** එකක් හදන්න (උදා: `global-translator`).
2. මේ ZIP එක extract කරලා ඇතුළේ තියෙන සියලුම ෆයිල් (`.github` ෆෝල්ඩරයත් එක්ක) repository එකේ `main` branch එකට upload කරන්න.
3. Repo එකේ **Settings → Pages → Build and deployment → Source** එක **GitHub Actions** විදිහට තෝරන්න.
4. තත්පර 30කින් ඔයාගේ ඇප් එක `https://<username>.github.io/<repo-name>/` ලින්ක් එකෙන් Live වේ!

## 2. ෆෝන් වලට Install කිරීම සහ Android APK එකක් සෑදීම
- **PWA Install:** Chrome එකෙන් ලින්ක් එක ඇරලා ඇප් එකේ උඩම පේන **📲 Install App** බොත්තම ඔබන්න.
- **Android APK (Auto-Updating):** [PWABuilder](https://www.pwabuilder.com/) වෙත ගිහින් ඔයාගේ GitHub Pages ලින්ක් එක දීලා **Android (TWA) APK** එක ඩවුන්ලෝඩ් කරගන්න.

## 3. හැමෝගෙම ෆෝන් වල ඔටෝ අප්ඩේට් වෙන්න Update එකක් දාන විදිහ
1. `index.html` එකේ ඔයාට ඕනේ වෙනස්කම් කරන්න.
2. `version.json` එකේ `"version": "2.0.1"` විදිහට සහ `sw.js` එකේ පළවෙනි පේළිය `APP_CACHE = 'global-hybrid-translator-shell-v2.0.1'` විදිහට අංකය වෙනස් කරලා GitHub එකට Commit කරන්න.
3. එතකොට PWA හෝ APK install කරගෙන ඉන්න හැමෝගෙම ෆෝන් වල ඉන්ටර්නෙට් තියෙන ඊළඟ අවස්ථාවේදී ඇප් එක ස්වයංක්‍රීයවම අප්ඩේට් වේ (ඩවුන්ලෝඩ් කරපු ඕෆ්ලයින් AI මොඩල් මැකෙන්නේ නැහැ!).
